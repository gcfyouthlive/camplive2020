
                            README.TXT - 23/3/97
                           =======================
This document contains information about installing and using the 
TrueType font file "Scramble" Version 1.00

Installation
------------
There are two ways you can install the font file, either to the windows 
system directory or to a separate directory.

Windows System Directory
------------------------
To install the font file to the windows system directory do the 
following:-

1) In program manager, open the CONTROL PANEL Program
2) Open the FONTS Section
3) Press ADD..
4) Select the directory where the fonts are located e.g. A:\TRUETYPE
5) Press Select All.
6) Check the box "Copy Fonts to System directory"
7) Select OK
8) Close CONTROL PANEL.

Alternative Directory
---------------------
To install the font file to an alternative directory do the following:-

1) Use FILE MANAGER to create the directory you want the font files to be in
2) Copy all the files from the distribution disk / directory to the font
   directory.
3) In PROGRAM MANAGER, open the CONTROL PANEL Program
4) Open the FONTS Section
5) Press ADD..
6) Select the directory where the fonts are located e.g. C:\FONTS
7) Press Select All.
8) UnCheck the box "Copy Fonts to System directory"
9) Select OK
10)Close CONTROL PANEL.

The file SCRAMBLE.??? has been saved in four file formats,and shows all the
Letters.

.DOC - Microsoft Word for Windows 6.0
.WRI - Microsoft Write
.RTF - Rich Text Format

Registration
------------
If you like the font and intend to use it, please register it, All it will 
cost you is �5.00 Stirling.
See REGISTER.TXT for more information.

Registered Users are entitled to six months unlimited eMail support and
will automatically receive any major bug fixes during this period.

Thank you for reading this far!!

I hope the font will be as much use to you as it is to me, Please send me 
any comments or suggestions on this font or any other fonts you think may 
be useful.

Thanks
Simon Daykin
    ____        __            _____ _                __                     
   / __ )__  __/ /____       / ___/(_)___  ___  ____/ / _________  ____ ___ 
  / __  / / / / __/ _ \______\__ \/ /_  / / _ \/ __  / / ___/ __ \/ __ `__ \
 / /_/ / /_/ / /_/  __/_____/__/ / / / /_/  __/ /_/ /_/ /__/ /_/ / / / / / /
/_____/\__, /\__/\___/     /____/_/ /___/\___/\__,_/(_)___/\____/_/ /_/ /_/ 
      /____/                                                                
E-Mail : Simon@Byte-Sized.com                    Web : http://Byte-Sized.com
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
------------------------------ End of Document ------------------------------